import java.io.*;
import java.net.*;
import java.util.Scanner;

public class AuctionClient {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Thread serverListenerThread;

    public AuctionClient(String host, int port) {
        try {
            socket = new Socket(host, port);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            System.out.println("Connected to server at " + host + ":" + port);
        } catch (IOException e) {
            System.err.println("Error connecting to server: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void chooseAuction(int auctionId) {
        sendCommand("CHOOSE " + auctionId);
    }

    public void raisePrice(int newPrice) {
        sendCommand("BID " + newPrice);
    }

    public String getTimeLeft() {
        sendCommand("TIME_LEFT");
        String response = "";
        try {
            response = in.readLine();
        } catch (IOException e) {
            System.err.println("Error reading time left: " + e.getMessage());
            e.printStackTrace();
        }
        return response;
    }

    private void sendCommand(String command) {
        out.println(command);
    }

    public void startListening() {
        serverListenerThread = new Thread(() -> {
            try {
                String serverResponse;
                while ((serverResponse = in.readLine()) != null) {
                    System.out.println("Server says: " + serverResponse);
                    // Process the server response as needed
                }
            } catch (IOException e) {
                if (!socket.isClosed()) {
                    System.err.println("Error listening to server: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });
        serverListenerThread.start();
    }

    public void close() {
        try {
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null) socket.close();
            if (serverListenerThread != null) {
                serverListenerThread.interrupt(); // Stop the listening thread
            }
            System.out.println("Connection closed.");
        } catch (IOException e) {
            System.err.println("Error closing connection: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Example usage
        AuctionClient client = new AuctionClient("localhost", 1234);
        client.startListening(); // Start listening to server messages

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter auction ID to choose:");
        int auctionId = scanner.nextInt();
        client.chooseAuction(auctionId);

        System.out.println("Enter your bid amount:");
        int bidAmount = scanner.nextInt();
        client.raisePrice(bidAmount);

        String timeLeft = client.getTimeLeft();
        System.out.println("Time left: " + timeLeft);

        // Close the connection
        client.close();
        scanner.close();
    }
}