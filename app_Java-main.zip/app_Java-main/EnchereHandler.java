public class EnchereHandler {
    import java.io.*;
import java.net.*;
import java.util.*;

public class EnchereHandler implements Runnable {
    private Socket clientSocket;
    private BufferedReader in;
    private PrintWriter out;
    private static int highestBid = 0;
    private static String highestBidder = "";
    private static Timer timer;
    private static boolean auctionActive = true;

    public EnchereHandler(Socket socket) {
        this.clientSocket = socket;
        try {
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            out = new PrintWriter(clientSocket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            out.println("Welcome to the auction! Current highest bid: " + highestBid);
            String clientMessage;
            while ((clientMessage = in.readLine()) != null && auctionActive) {
                int bidAmount = Integer.parseInt(clientMessage);
                if (bidAmount > highestBid) {
                    highestBid = bidAmount;
                    highestBidder = clientSocket.getInetAddress().toString();
                    out.println("Bid accepted. Current highest bid: " + highestBid);
                    resetTimer();
                } else {
                    out.println("Bid too low. Current highest bid: " + highestBid);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                in.close();
                out.close();
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void resetTimer() {
        if (timer != null) {
            timer.cancel();
        }
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                auctionActive = false;
                System.out.println("Auction closed. Highest bid: " + highestBid + " by " + highestBidder);
                out.println("Auction closed. Highest bid: " + highestBid + " by " + highestBidder);
            }
        }, 10000); // 10 seconds timeout
    }
}
}
